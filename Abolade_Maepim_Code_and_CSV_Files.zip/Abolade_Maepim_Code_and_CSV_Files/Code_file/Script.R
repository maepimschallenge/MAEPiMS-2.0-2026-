library(tidyverse)
library(cmdstanr)
library(posterior)
library(bayesplot)

set_cmdstan_path("C:/Users/user/.cmdstan/cmdstan-2.39.0")
options(mc.cores = parallel::detectCores())

# -----------------------------------------------------------------------------
# 1. Load Data and Format Regional Vectors
# -----------------------------------------------------------------------------
state_meta <- read.csv("nigeria_flu_state_metadata.csv")
weekly_df  <- read.csv("nigeria_flu_weekly_by_state.csv")

pop_col <- intersect(c("pop_size", "population", "pop", "N"), colnames(state_meta))[1]

state_meta <- state_meta %>%
  arrange(state) %>%
  mutate(
    state_id    = row_number(),
    climate_idx = as.integer(factor(climate, levels = c("sahel", "savanna", "tropical"))),
    pop_vector  = .data[[pop_col]],
    # Classify Northern states (Sahel/Savanna) for regional targets
    is_north_val = ifelse(climate %in% c("sahel", "savanna"), 1.0, 0.0)
  )

weekly_df <- weekly_df %>%
  arrange(state, iso_year, iso_week) %>%
  group_by(state) %>%
  mutate(time_idx = row_number()) %>%
  ungroup()

create_matrix <- function(df, target_col) {
  mat <- df %>%
    arrange(state, time_idx) %>%
    pivot_wider(
      id_cols     = state, 
      names_from  = time_idx, 
      values_from = all_of(target_col),
      values_fill = 0
    ) %>%
    arrange(state) %>%
    select(-state) %>%
    as.matrix()
  
  storage.mode(mat) <- "integer"
  return(mat)
}

cases_mat  <- create_matrix(weekly_df, "cases")
hosp_mat   <- create_matrix(weekly_df, "hospitalizations")
deaths_mat <- create_matrix(weekly_df, "deaths")

# -----------------------------------------------------------------------------
# 2. Assemble Stan Data List (With 52-Week Forecast Horizon)
# -----------------------------------------------------------------------------
T_obs  <- ncol(cases_mat)
T_pred <- 52

stan_data <- list(
  S            = nrow(cases_mat), 
  T_obs        = T_obs, 
  T_pred       = T_pred,
  C            = 3, 
  
  cases_mat    = cases_mat,
  hosp_mat     = hosp_mat,
  deaths_mat   = deaths_mat,
  
  climate_zone = as.integer(state_meta$climate_idx),
  hc_access    = as.vector(scale(state_meta$hc_access)),
  state_pop    = as.numeric(state_meta$pop_vector),
  is_north     = as.numeric(state_meta$is_north_val)
)

# -----------------------------------------------------------------------------
# 3. Initial Values Function
# -----------------------------------------------------------------------------
S <- stan_data$S
C <- stan_data$C

init_fun <- function() {
  list(
    gamma        = runif(1, 1.35, 1.45),
    sigma        = runif(1, 3.40, 3.60),
    omega        = runif(1, 0.008, 0.012),
    mu_beta      = runif(C, 1.8, 2.2),
    sd_beta      = runif(1, 0.05, 0.10),
    beta_0_raw   = rnorm(S, 0, 0.05),
    A1           = rnorm(C, 0, 0.02),
    A2           = rnorm(C, 0, 0.02),
    dev_beta     = matrix(rnorm(S * T_obs, 0, 0.005), nrow = S, ncol = T_obs),
    dev_beta_pred= matrix(rnorm(S * T_pred, 0, 0.005), nrow = S, ncol = T_pred),
    sigma_beta   = runif(1, 0.01, 0.03),
    mu_rho_logit = runif(1, -2.1, -1.9),
    sd_rho_logit = runif(1, 0.02, 0.05),
    rho_raw      = rnorm(S, 0, 0.05),
    alpha_hosp   = runif(1, -3.6, -3.4),
    beta_hosp    = runif(1, -0.05, 0.05),
    alpha_cfr    = runif(1, -2.1, -1.9),
    beta_cfr     = runif(1, -0.05, 0.05),
    phi_cases    = runif(S, 10, 20),
    phi_hosp     = runif(1, 10, 20),
    phi_deaths   = runif(1, 10, 20),
    log_i0       = runif(S, -5.8, -5.2)
  )
}

# -----------------------------------------------------------------------------
# 4. Compile and Run MCMC Sampling
# -----------------------------------------------------------------------------
mod <- cmdstan_model(
  stan_file = "SEIRH_forecast.stan", 
  cpp_options = list(stan_threads = TRUE),
  force_recompile = TRUE
)

fit <- mod$sample(
  data              = stan_data,
  init              = init_fun,
  seed              = 2026,
  chains            = 4,
  parallel_chains   = 2,
  threads_per_chain = 2,
  iter_warmup       = 500,
  iter_sampling     = 500,
  adapt_delta       = 0.88,
  max_treedepth     = 10
)

# Save output object & data
fit$draws()
fit$save_object(file = "stan_fit_52week_forecast.rds")
saveRDS(stan_data, file = "stan_data_52week.rds")


#  How to resume after restart
library(tidyverse)
library(cmdstanr)
library(posterior)

# 1. Reload saved fit object and metadata from disk
fit        <- readRDS("stan_fit_52week_forecast.rds")
stan_data  <- readRDS("stan_data_52week.rds")
state_meta <- readRDS("state_meta.rds")

# # 2. Verify model fit loaded correctly
#print(fit$summary(c("gamma", "sigma", "omega", "sigma_beta")))

# Now you can execute all plotting or extraction steps directly!
# -----------------------------------------------------------------------------
# 5. Diagnostic PDF Summaries
# -----------------------------------------------------------------------------
draws_all <- fit$draws()

pdf("diagnostics_core_trace_dens.pdf", width = 11, height = 8.5)
print(mcmc_trace(draws_all, pars = c("gamma", "sigma", "omega", "sigma_beta", "mu_rho_logit")))
print(mcmc_dens_overlay(draws_all, pars = c("gamma", "sigma", "omega", "sigma_beta", "mu_rho_logit")))
dev.off()



# ==============================================================================
# 1. EXTRACT & SAVE FULL PARAMETER SUMMARY TABLE (All 5,000+ Parameters)
# ==============================================================================
cat("Extracting summary for all estimated parameters...\n")

# Compute mean, median, sd, quantiles, Rhat, and ESS for every parameter
param_summary <- fit$summary(
  variables = NULL, # NULL extracts all parameters automatically
  "mean", "median", "sd", "mad",
  ~quantile(.x, probs = c(0.025, 0.05, 0.25, 0.50, 0.75, 0.95, 0.975)),
  "rhat", "ess_bulk", "ess_tail"
)

# Save as CSV for reporting, peer review, and submission appendix
write.csv(param_summary, "Estimated_Parameter_summary_all.csv", row.names = FALSE)
cat("✔ Saved 'stan_parameter_summary_all.csv'\n")




# ==============================================================================
# 2. EXTRACT & SAVE  PROBABILISTIC TARGETS 
# ==============================================================================
cat("Extracting posterior predictions (cases, hospitalizations, deaths)...\n")

# 1. Add T_total directly to your existing stan_data list in R
stan_data$T_total <- stan_data$T_obs + stan_data$T_pred

# 2. Re-save your updated data list so you have it for future sessions
saveRDS(stan_data, file = "stan_data_52week.rds")

base_grid <- expand.grid(s = 1:stan_data$S, t = 1:stan_data$T_total) %>%
  mutate(
    state_name = state_meta$state[s],
    period     = ifelse(t <= stan_data$T_obs, "Historical", "Forecast")
  )

extract_predictions <- function(param_prefix, obs_matrix, stream_name) {
  draws_mat <- fit$draws(param_prefix, format = "draws_matrix")
  
  # Generate explicit parameter names (e.g., "cases_rep[1,1]")
  param_names <- sprintf("%s[%d,%d]", param_prefix, base_grid$s, base_grid$t)
  
  # Ensure target columns exist in draws_mat
  valid_names <- intersect(param_names, colnames(draws_mat))
  
  # Pad observed matrix with NA for the forecast period
  obs_padded <- c(
    as.vector(obs_matrix), 
    rep(NA, stan_data$S * stan_data$T_pred)
  )
  
  # Force as 2D matrix to prevent colMeans dropping dimension
  cols <- as.matrix(draws_mat[, valid_names])
  
  df <- base_grid %>%
    mutate(
      stream   = stream_name,
      observed = obs_padded,
      mean     = colMeans(cols),
      median   = apply(cols, 2, median),
      q2.5     = apply(cols, 2, quantile, probs = 0.025),
      q5       = apply(cols, 2, quantile, probs = 0.05),
      q25      = apply(cols, 2, quantile, probs = 0.25),
      q75      = apply(cols, 2, quantile, probs = 0.75),
      q95      = apply(cols, 2, quantile, probs = 0.95),
      q97.5    = apply(cols, 2, quantile, probs = 0.975)
    )
  return(df)
}
# Process all 3 outcome streams
cases_summary <- extract_predictions("cases_rep", stan_data$cases_mat, "Cases")
hosp_summary  <- extract_predictions("hosp_rep",  stan_data$hosp_mat,  "Hospitalizations")
death_summary <- extract_predictions("deaths_rep", stan_data$deaths_mat, "Deaths")

# Combine into a single forecast summary table
pred_summary_all <- bind_rows(cases_summary, hosp_summary, death_summary)

# Save forecast dataset to CSV
write.csv(pred_summary_all, "Raw_and Forecast_Fitting_data_summary.csv", row.names = FALSE)
cat("✔ Saved 'Raw_and Forecast_Fitting_data_summary.csv'\n")






# ==============================================================================
# 1. HELPER FUNCTIONS FOR MULTI-PAGE DIAGNOSTIC PLOTS
# ==============================================================================

# Generic Trace Plotter
plot_trace_pages <- function(draws_obj, param_list, title_prefix, per_page = 6) {
  n_total <- length(param_list)
  n_pages <- ceiling(n_total / per_page)
  
  for (i in 1:n_pages) {
    idx_start  <- (i - 1) * per_page + 1
    idx_end    <- min(i * per_page, n_total)
    sub_params <- param_list[idx_start:idx_end]
    
    p <- mcmc_trace(draws_obj, pars = sub_params) +
      labs(title = paste0(title_prefix, " (Page ", i, " of ", n_pages, ")")) +
      theme_bw(base_size = 11)
    
    print(p)
  }
}

# Generic Density Plotter
plot_dens_pages <- function(draws_obj, param_list, title_prefix, per_page = 6) {
  n_total <- length(param_list)
  n_pages <- ceiling(n_total / per_page)
  
  for (i in 1:n_pages) {
    idx_start  <- (i - 1) * per_page + 1
    idx_end    <- min(i * per_page, n_total)
    sub_params <- param_list[idx_start:idx_end]
    
    p <- mcmc_dens_overlay(draws_obj, pars = sub_params) +
      labs(title = paste0(title_prefix, " (Page ", i, " of ", n_pages, ")")) +
      theme_bw(base_size = 11)
    
    print(p)
  }
}


# ==============================================================================
# 3. DEFINE PARAMETER GROUPS TO BE PLOTTED IN THE DIAGNOSTIC PLOTS
# ==============================================================================

# Parameter Group Definitions
global_params   <- c("gamma", "sigma", "omega", "sigma_beta", "mu_rho_logit", "sd_rho_logit", "sd_beta")
climate_params  <- c("mu_beta[1]", "mu_beta[2]", "mu_beta[3]", 
                     "A1[1]", "A1[2]", "A1[3]", 
                     "A2[1]", "A2[2]", "A2[3]")
clinical_params <- c("alpha_hosp", "beta_hosp", "alpha_cfr", "beta_cfr", "phi_hosp", "phi_deaths")
core_params     <- c(global_params, climate_params, clinical_params)

# Vectorized state-level parameters
rho_params   <- paste0("rho[", 1:stan_data$S, "]")
beta0_params <- paste0("beta_0[", 1:stan_data$S, "]")
eta_params   <- paste0("eta[", 1:stan_data$S, "]")
cfr_params   <- paste0("CFR[", 1:stan_data$S, "]")
phi_c_params <- paste0("phi_cases[", 1:stan_data$S, "]")

# PDF 2: Trace Plots (Combined into a single multi-page PDF)
pdf_trace <- "diagnostics_trace_plots.pdf"
tryCatch({
  pdf(pdf_trace, width = 11, height = 8.5)
  
  plot_trace_pages(draws_all, core_params, "Trace Plots: Core & Global Parameters", per_page = 6)
  plot_trace_pages(draws_all, rho_params, "Trace Plots: State Reporting Rates (rho)", per_page = 6)
  plot_trace_pages(draws_all, beta0_params, "Trace Plots: State Baseline Transmission (beta_0)", per_page = 6)
  plot_trace_pages(draws_all, eta_params, "Trace Plots: State Hospitalization Rates (eta)", per_page = 6)
  plot_trace_pages(draws_all, cfr_params, "Trace Plots: State Case Fatality Rates (CFR)", per_page = 6)
  plot_trace_pages(draws_all, phi_c_params, "Trace Plots: Case Dispersion (phi_cases)", per_page = 6)
  
}, finally = {
  dev.off()
})
cat("Saved:", pdf_trace, "| Size:", file.info(pdf_trace)$size, "bytes\n")

# ==============================================================================
# 4. MULTI-PAGE DENSITY PLOTS PDF
# ==============================================================================

# PDF 3: Posterior Density Overlays
pdf_dens <- "diagnostics_density_plots.pdf"
tryCatch({
  pdf(pdf_dens, width = 11, height = 8.5)
  
  plot_dens_pages(draws_all, core_params, "Posterior Densities: Core Parameters", per_page = 6)
  plot_dens_pages(draws_all, rho_params, "Posterior Densities: State Reporting Rates (rho)", per_page = 6)
  plot_dens_pages(draws_all, beta0_params, "Posterior Densities: State Transmission (beta_0)", per_page = 6)
  plot_dens_pages(draws_all, eta_params, "Posterior Densities: State Hospitalization (eta)", per_page = 6)
  plot_dens_pages(draws_all, cfr_params, "Posterior Densities: State CFR", per_page = 6)
  
}, finally = {
  dev.off()
})
cat("Saved:", pdf_dens, "| Size:", file.info(pdf_dens)$size, "bytes\n")

# ==============================================================================
# 5. STRUCTURED PAIRS PLOTS PDF
# ==============================================================================

# PDF 4: MCMC Pairs Diagnostics
pdf_pairs <- "diagnostics_pairs_plots.pdf"
tryCatch({
  pdf(pdf_pairs, width = 12, height = 12)
  
  print(mcmc_pairs(draws_all, pars = c("gamma", "sigma", "omega", "sigma_beta"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  print(mcmc_pairs(draws_all, pars = c("mu_beta[1]", "mu_beta[2]", "mu_beta[3]", "mu_rho_logit", "sd_rho_logit", "sd_beta"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  print(mcmc_pairs(draws_all, pars = c("alpha_hosp", "beta_hosp", "alpha_cfr", "beta_cfr", "phi_hosp", "phi_deaths"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  print(mcmc_pairs(draws_all, pars = c("beta_0[1]", "beta_0[2]", "beta_0[3]", "rho[1]", "rho[2]", "rho[3]"), off_diag_args = list(size = 0.8, alpha = 0.3)))
  
}, finally = {
  dev.off()
})
cat("Saved:", pdf_pairs, "| Size:", file.info(pdf_pairs)$size, "bytes\n")

# Final verification step
while (dev.cur() > 1) dev.off()






# -----------------------------------------------------------------------------
# 6. Extract & Plot National Forecasts (Cases, Hospitalizations, Deaths)
# -----------------------------------------------------------------------------
cat("Extracting National Forecasts...\n")

T_total <- T_obs + T_pred

extract_national_target <- function(param_name, label_str) {
  mat <- fit$draws(param_name, format = "draws_matrix")
  tibble(
    week     = 1:T_total,
    target   = label_str,
    is_fwd   = week > T_obs,
    median   = apply(mat, 2, median),
    q5       = apply(mat, 2, quantile, probs = 0.05),
    q25      = apply(mat, 2, quantile, probs = 0.25),
    q75      = apply(mat, 2, quantile, probs = 0.75),
    q95      = apply(mat, 2, quantile, probs = 0.95)
  )
}

nat_cases  <- extract_national_target("national_cases_sim", "National Cases")
nat_hosp   <- extract_national_target("national_hosp_sim", "National Hospitalizations")
nat_deaths <- extract_national_target("national_deaths_sim", "National Deaths")

national_all <- bind_rows(nat_cases, nat_hosp, nat_deaths)

# Save National CSV Output
write.csv(national_all, "National_52week_forecasts.csv", row.names = FALSE)

# Generate PDF Plot for Primary & Secondary Tasks
pdf("National_Level_52Week_Forecasts (Primary and Seondary).pdf", width = 11, height = 8.5)

p_nat <- ggplot(national_all, aes(x = week)) +
  geom_ribbon(aes(ymin = q5, ymax = q95), fill = "#1F78B4", alpha = 0.25) +
  geom_ribbon(aes(ymin = q25, ymax = q75), fill = "#1F78B4", alpha = 0.45) +
  geom_line(aes(y = median), color = "#08306B", linewidth = 1.0) +
  geom_vline(xintercept = T_obs + 0.5, linetype = "dashed", color = "red", linewidth = 0.8) +
  facet_wrap(~ target, ncol = 1, scales = "free_y") +
  labs(
    title = "Primary & Secondary Tasks: 52-Week Ahead Probabilistic Forecasts for Nigeria",
    subtitle = "Historical Fit (Left of dashed line) vs 52-Week Forecast (Right) with 50% & 90% Intervals",
    x = "Epidemiological Week",
    y = "Weekly Count"
  ) +
  theme_bw(base_size = 12) +
  theme(strip.background = element_rect(fill = "grey90"), strip.text = element_text(face = "bold"))

print(p_nat)
dev.off()

cat("✔ Sampling and 52-Week Forecast (National) Generation Completed Successfully!\n")





# =============================================================================
# 7. Extract State-Level 52-Week Forecasts (Cases, Hosp, Deaths)
# =============================================================================
cat("Extracting State-by-State Forecasts...\n")

extract_state_matrix <- function(fit_obj, param_base_name, target_label, state_meta_df, T_obs, T_total) {
  # Get all matching parameter names for this matrix [S, T_total]
  draws_mat <- fit_obj$draws(param_base_name, format = "draws_matrix")
  
  state_records <- list()
  
  for (s in 1:nrow(state_meta_df)) {
    st_name <- state_meta_df$state[s]
    
    for (t in 1:T_total) {
      col_name <- sprintf("%s[%d,%d]", param_base_name, s, t)
      vals <- draws_mat[, col_name]
      
      state_records[[length(state_records) + 1]] <- tibble(
        state     = st_name,
        week      = t,
        target    = target_label,
        is_fwd    = t > T_obs,
        median    = median(vals),
        q5        = quantile(vals, 0.05),
        q25       = quantile(vals, 0.25),
        q75       = quantile(vals, 0.75),
        q95       = quantile(vals, 0.95)
      )
    }
  }
  bind_rows(state_records)
}

# Extract all three targets across all 37 states
state_cases  <- extract_state_matrix(fit, "cases_rep",  "Cases",            state_meta, T_obs, T_total)
state_hosp   <- extract_state_matrix(fit, "hosp_rep",   "Hospitalizations", state_meta, T_obs, T_total)
state_deaths <- extract_state_matrix(fit, "deaths_rep", "Deaths",           state_meta, T_obs, T_total)

state_all_targets <- bind_rows(state_cases, state_hosp, state_deaths)

# Save complete state-level forecast dataset
write.csv(state_all_targets, "maepims_state_level_52week_forecasts.csv", row.names = FALSE)
cat("Saved: All_State_Raw_and Forecast_Fitting_data.csv\n")




# =============================================================================
# 8. Generate Multi-Page State-by-State Plots (4 States per Page, 30 Pages Total)
# =============================================================================
cat("Generating Multi-Page High-Resolution State Plots (4 States per Page, 30 Pages Total)...\n")

library(ggplot2)
library(dplyr)

# Define layout settings
states_per_page <- 4
all_states <- sort(unique(state_all_targets$state))
num_states <- length(all_states)
pages_per_stream <- ceiling(num_states / states_per_page) # 10 pages per stream

# Configuration for outcome streams
stream_config <- list(
  Cases = list(fill = "#1F78B4", line = "#08306B"),
  Hospitalizations = list(fill = "#33A02C", line = "#004D40"),
  Deaths = list(fill = "#E31A1C", line = "#800000")
)

# Open a single master PDF file (30 pages total)
combined_pdf_filename <- "State_Level_52Week_Forecasts (Primary and  Secondary).pdf"
pdf(combined_pdf_filename, width = 11, height = 8.5) # Landscape orientation

# Loop through each target stream (Cases, Hospitalizations, Deaths)
for (target_name in names(stream_config)) {
  
  fill_color <- stream_config[[target_name]]$fill
  line_color <- stream_config[[target_name]]$line
  df_target  <- filter(state_all_targets, target == target_name)
  
  for (p in 1:pages_per_stream) {
    # Get the 4 states for this page
    start_idx   <- (p - 1) * states_per_page + 1
    end_idx     <- min(p * states_per_page, num_states)
    page_states <- all_states[start_idx:end_idx]
    
    df_page <- df_target %>% filter(state %in% page_states)
    
    p_page <- ggplot(df_page, aes(x = week)) +
      # 90% Prediction Interval
      geom_ribbon(aes(ymin = q5, ymax = q95), fill = fill_color, alpha = 0.25) +
      # 50% Prediction Interval
      geom_ribbon(aes(ymin = q25, ymax = q75), fill = fill_color, alpha = 0.45) +
      # Posterior Median Trajectory
      geom_line(aes(y = median), color = line_color, linewidth = 0.9) +
      # Forecast Boundary Line (T_obs Cutoff)
      geom_vline(xintercept = T_obs + 0.5, linetype = "dashed", color = "red", linewidth = 0.8) +
      # 2x2 Grid per page: forcing 2 columns and 2 rows explicitly
      facet_wrap(~ state, scales = "free_y", ncol = 2, nrow = 2) +
      labs(
        title = sprintf("%s 52-Week Forecast: Page %d of %d", target_name, p, pages_per_stream),
        subtitle = "Historical Fit (Left of Red Line) vs. 52-Week Forecast (Right)",
        x = "Epidemiological Week",
        y = sprintf("Weekly %s Count", target_name)
      ) +
      theme_bw(base_size = 12) +
      theme(
        strip.background = element_rect(fill = "#ECEFF1"),
        strip.text       = element_text(face = "bold", size = 12),
        panel.grid.minor = element_blank(),
        axis.text        = element_text(size = 10),
        axis.title       = element_text(size = 11, face = "bold")
      )
    
    print(p_page)
  }
}

dev.off()
cat(sprintf("✔ Saved Combined Document: %s (%d total pages)\n", combined_pdf_filename, pages_per_stream * length(stream_config)))








# ==============================================================================
# MAEPIMS FORECASTING WORKFLOW: TASTK 1:  SEASONAL TARGETS & VISUALIZATIONS
# ==============================================================================
library(forcats)
library(readr)

# ==============================================================================
# 1. EXTRACT POSTERIOR DRAWS (FORECAST HORIZON ONLY)
# ==============================================================================
cat("Extracting posterior draws for forecast parameters...\n")

mu_cases_draws  <- fit$draws("mu_cases", format = "draws_matrix")
mu_hosp_draws   <- fit$draws("mu_hosp", format = "draws_matrix")
mu_deaths_draws <- fit$draws("mu_deaths", format = "draws_matrix")

t_start <- stan_data$T_obs + 1
t_end   <- stan_data$T_total
forecast_weeks <- t_start:t_end

# Storage lists for draw summaries
list_ar       <- list()
list_cases    <- list()
list_hosp     <- list()
list_deaths   <- list()
list_pk_inc   <- list()
list_pk_week  <- list()

# Helper function to obtain state name safely
get_state_name <- function(s_idx) {
  base_grid %>% filter(s == s_idx) %>% pull(state_name) %>% unique()
}

# ==============================================================================
# 2. COMPUTE METRICS PER STATE (ACCROSS DRAWS)
# ==============================================================================
for (s_idx in 1:stan_data$S) {
  state_nm  <- get_state_name(s_idx)
  state_pop <- stan_data$state_pop[s_idx]
  
  # Matrix slices across forecast weeks [n_draws x n_forecast_weeks]
  cols <- sprintf("mu_cases[%d,%d]", s_idx, forecast_weeks)
  cases_mat  <- mu_cases_draws[, cols]
  
  cols_hosp <- sprintf("mu_hosp[%d,%d]", s_idx, forecast_weeks)
  hosp_mat   <- mu_hosp_draws[, cols_hosp]
  
  cols_death <- sprintf("mu_deaths[%d,%d]", s_idx, forecast_weeks)
  deaths_mat <- mu_deaths_draws[, cols_death]
  
  # ----------------------------------------------------------------------------
  # A. Cumulative Metrics Per Draw
  # ----------------------------------------------------------------------------
  cum_cases_draws  <- rowSums(cases_mat)
  cum_hosp_draws   <- rowSums(hosp_mat)
  cum_deaths_draws <- rowSums(deaths_mat)
  
  # Attack Rate (%)
  ar_draws <- (cum_cases_draws / state_pop) * 100
  
  list_ar[[s_idx]] <- data.frame(
    s = s_idx, state_name = state_nm,
    median = median(ar_draws), q5 = quantile(ar_draws, 0.05), q95 = quantile(ar_draws, 0.95),
    stringsAsFactors = FALSE
  )
  
  list_cases[[s_idx]] <- data.frame(
    s = s_idx, state_name = state_nm,
    median = median(cum_cases_draws), q5 = quantile(cum_cases_draws, 0.05), q95 = quantile(cum_cases_draws, 0.95),
    stringsAsFactors = FALSE
  )
  
  list_hosp[[s_idx]] <- data.frame(
    s = s_idx, state_name = state_nm,
    median = median(cum_hosp_draws), q5 = quantile(cum_hosp_draws, 0.05), q95 = quantile(cum_hosp_draws, 0.95),
    stringsAsFactors = FALSE
  )
  
  list_deaths[[s_idx]] <- data.frame(
    s = s_idx, state_name = state_nm,
    median = median(cum_deaths_draws), q5 = quantile(cum_deaths_draws, 0.05), q95 = quantile(cum_deaths_draws, 0.95),
    stringsAsFactors = FALSE
  )
  
  # ----------------------------------------------------------------------------
  # B. Peak Metrics Per Draw
  # ----------------------------------------------------------------------------
  # Peak Incidence: Maximum weekly cases in forecast window per draw
  pk_inc_draws <- apply(cases_mat, 1, max)
  
  # Peak Forecast Week: Week index (1 to 52) where peak occurs per draw
  pk_rel_week_draws <- apply(cases_mat, 1, which.max)
  
  list_pk_inc[[s_idx]] <- data.frame(
    s = s_idx, state_name = state_nm,
    median = median(pk_inc_draws), q5 = quantile(pk_inc_draws, 0.05), q95 = quantile(pk_inc_draws, 0.95),
    stringsAsFactors = FALSE
  )
  
  list_pk_week[[s_idx]] <- data.frame(
    s = s_idx, state_name = state_nm,
    median_rel_week = median(pk_rel_week_draws),
    q5_rel_week     = quantile(pk_rel_week_draws, 0.05),
    q95_rel_week    = quantile(pk_rel_week_draws, 0.95),
    median_abs_week = median(pk_rel_week_draws) + stan_data$T_obs,
    stringsAsFactors = FALSE
  )
}

# ==============================================================================
# 3. BIND AND SAVE CSV DATA
# ==============================================================================
df_ar        <- bind_rows(list_ar)
df_cases     <- bind_rows(list_cases)
df_hosp      <- bind_rows(list_hosp)
df_deaths    <- bind_rows(list_deaths)
df_pk_inc    <- bind_rows(list_pk_inc)
df_pk_week   <- bind_rows(list_pk_week)

write_csv(df_ar,      "Forecast_Seasonal_Attack_Rate.csv")
write_csv(df_cases,   "Forecast_Cumulative_Cases.csv")
write_csv(df_hosp,    "Forecast_Cumulative_Hospitalizations.csv")
write_csv(df_deaths,  "Forecast_Cumulative_Deaths.csv")
write_csv(df_pk_inc,  "Forecast_Peak_Incidence.csv")
write_csv(df_pk_week, "Forecast_Peak_Week.csv")

# Save combined master table
df_master <- df_ar %>% select(s, state_name, ar_median = median, ar_q5 = q5, ar_q95 = q95) %>%
  left_join(df_cases   %>% select(s, cases_median = median, cases_q5 = q5, cases_q95 = q95), by = "s") %>%
  left_join(df_hosp    %>% select(s, hosp_median = median, hosp_q5 = q5, hosp_q95 = q95), by = "s") %>%
  left_join(df_deaths  %>% select(s, deaths_median = median, deaths_q5 = q5, deaths_q95 = q95), by = "s") %>%
  left_join(df_pk_inc  %>% select(s, pk_inc_median = median, pk_inc_q5 = q5, pk_inc_q95 = q95), by = "s") %>%
  left_join(df_pk_week %>% select(s, peak_forecast_week = median_rel_week, peak_absolute_week = median_abs_week), by = "s")

write_csv(df_master, "Forecast_Seasonal_Master_Metrics.csv")
cat("✔ All CSV files exported successfully.\n")

# ==============================================================================
# 4. PLOTTING FUNCTION FOR HORIZONTAL DOT-PLOTS
# ==============================================================================
make_metric_plot <- function(data, title_str, x_label_str, is_percent = FALSE, custom_breaks = NULL) {
  df_plot <- data %>% mutate(state_name = fct_reorder(state_name, median))
  
  p <- ggplot(df_plot, aes(x = median, y = state_name)) +
    geom_errorbarh(aes(xmin = q5, xmax = q95), height = 0.35, color = "#1F78B4", linewidth = 0.75) +
    geom_point(color = "#1F78B4", size = 2.4) +
    labs(
      title = title_str,
      subtitle = "Posterior Median and 90% Credible Interval over 52-Week Forecast Horizon",
      x = x_label_str,
      y = NULL
    ) +
    theme_bw(base_size = 11) +
    theme(
      axis.text.y = element_text(size = 9, face = "bold", color = "black"),
      axis.text.x = element_text(size = 10, face = "bold", color = "black"),
      axis.title.x = element_text(size = 11, face = "bold", margin = margin(t = 8)),
      panel.grid.minor = element_blank(),
      panel.grid.major.y = element_line(color = "grey92", linewidth = 0.4),
      plot.title = element_text(face = "bold", size = 13),
      plot.subtitle = element_text(size = 10, color = "grey30")
    )
  
  if (is_percent) {
    p <- p + scale_x_continuous(
      limits = c(5, 16.5),
      breaks = seq(5, 16, by = 1),
      labels = function(x) paste0(x, "%"),
      expand = c(0, 0)
    )
  } else if (!is.null(custom_breaks)) {
    p <- p + scale_x_continuous(breaks = custom_breaks)
  } else {
    p <- p + scale_x_continuous(labels = scales::comma)
  }
  
  return(p)
}

# Generate figures
p_ar     <- make_metric_plot(df_ar,     "Forecasted Seasonal Attack Rate by State", "Seasonal Attack Rate (%)", is_percent = TRUE)
p_cases  <- make_metric_plot(df_cases,  "Forecasted Seasonal Cumulative Cases by State", "Cumulative Cases")
p_hosp   <- make_metric_plot(df_hosp,   "Forecasted Seasonal Cumulative Hospitalizations by State", "Cumulative Hospitalizations")
p_deaths <- make_metric_plot(df_deaths, "Forecasted Seasonal Cumulative Deaths by State", "Cumulative Deaths")
p_pk_inc <- make_metric_plot(df_pk_inc, "Forecasted Peak Weekly Case Incidence by State", "Peak Weekly Cases")

# Peak Week plot (Discrete integer scale)
df_pk_week_plot <- df_pk_week %>% mutate(state_name = fct_reorder(state_name, median_rel_week))
p_pk_week <- ggplot(df_pk_week_plot, aes(x = median_rel_week, y = state_name)) +
  geom_errorbarh(aes(xmin = q5_rel_week, xmax = q95_rel_week), height = 0.35, color = "#33A02C", linewidth = 0.75) +
  geom_point(color = "#33A02C", size = 2.4) +
  scale_x_continuous(breaks = seq(0, 52, by = 4), limits = c(1, 52)) +
  labs(
    title = "Forecasted Peak Week Timing by State",
    subtitle = "Posterior Median Peak Forecast Week (1 to 52) with 90% Credible Interval",
    x = "Forecast Week of Peak Incidence",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(
    axis.text.y = element_text(size = 9, face = "bold", color = "black"),
    axis.text.x = element_text(size = 10, face = "bold", color = "black"),
    axis.title.x = element_text(size = 11, face = "bold", margin = margin(t = 8)),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "grey92", linewidth = 0.4),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey30")
  )

# ==============================================================================
# 5. EXPORT MULTI-PAGE PDF REPORT
# ==============================================================================
pdf_filename <- "Forecasted_Seasonal_Metrics_Nigeria.pdf"

tryCatch({
  pdf(pdf_filename, width = 8.5, height = 11)
  print(p_ar)
  print(p_cases)
  print(p_hosp)
  print(p_deaths)
  print(p_pk_inc)
  print(p_pk_week)
}, finally = {
  if (dev.cur() > 1) dev.off()
})

cat("✔ Multi-page PDF report generated successfully:", pdf_filename, "\n")





library(forcats)

# ==============================================================================
# 1. EXTRACT MU_CASES & CALCULATE ATTACK RATES PER DRAW
# ==============================================================================
mu_cases_draws <- fit$draws("mu_cases", format = "draws_matrix")

t_start <- stan_data$T_obs + 1
t_end   <- stan_data$T_total

draw_ar_list <- list()

for (s_idx in 1:stan_data$S) {
  cols <- sprintf("mu_cases[%d,%d]", s_idx, t_start:t_end)
  state_cum_cases <- rowSums(mu_cases_draws[, cols])
  state_pop_val   <- stan_data$state_pop[s_idx]
  draw_ar_pct     <- (state_cum_cases / state_pop_val) * 100
  
  draw_ar_list[[s_idx]] <- data.frame(
    s          = s_idx,
    state_name = base_grid %>% filter(s == s_idx) %>% pull(state_name) %>% unique(),
    ar_median  = median(draw_ar_pct),
    ar_q5      = quantile(draw_ar_pct, 0.05),
    ar_q95     = quantile(draw_ar_pct, 0.95),
    stringsAsFactors = FALSE
  )
}



ar_clean_df <- bind_rows(draw_ar_list) %>%
  mutate(state_name = fct_reorder(state_name, ar_median))


p_clean <- ggplot(ar_clean_df, aes(x = ar_median, y = state_name)) +
  geom_errorbarh(aes(xmin = ar_q5, xmax = ar_q95), height = 0.35, color = "#1F78B4", linewidth = 0.75) +
  geom_point(color = "#1F78B4", size = 2.4) +
  scale_x_continuous(
    limits = c(5, 16.5),
    breaks = seq(5, 16, by = 1),
    labels = function(x) paste0(x, "%"),
    expand = c(0, 0)
  ) +
  labs(
    title = "Forecasted Seasonal Attack Rate by State",
    subtitle = "Posterior Median and 90% Credible Interval over 52-Week Horizon",
    x = "Forecasted Seasonal Attack Rate (%)",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(
    axis.text.y = element_text(size = 9, face = "bold", color = "black"),
    axis.text.x = element_text(size = 10, face = "bold", color = "black"),
    axis.title.x = element_text(size = 11, face = "bold", margin = margin(t = 8)),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "grey92", linewidth = 0.4),
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 10, color = "grey30")
  )

# Export PDF
pdf_file <- "Forecasted_Seasonal_Attack_Rate_Nigeria.pdf"

tryCatch({
  pdf(pdf_file, width = 8, height = 10.5)
  print(p_clean)
}, finally = {
  if (dev.cur() > 1) dev.off()
})

cat("✔ Corrected plot exported successfully:", pdf_file, "\n")





library(dplyr)
library(readr)
library(ggplot2)
library(forcats)
library(scoringutils) # For CRPS and WIS scoring

# ==============================================================================
# 1. SETUP FORECAST HORIZON AND SPATIAL MAPPINGS
# ==============================================================================
cat("--- Setting up Spatial Hierarchies and Forecast Horizon ---\n")

# Use exact forecast window variables
t_start <- stan_data$T_obs + 1
t_end   <- stan_data$T_total
forecast_weeks <- t_start:t_end
n_forecast <- length(forecast_weeks)

# Assign Geopolitical Regions & North/South Classification
# Exact 37 Spatial Units (19 Northern States/FCT + 18 Southern States)
region_mapping <- data.frame(
  state_name = c(
    # Northern States & FCT (19 total)
    "Kano", "Katsina", "Kaduna", "Jigawa", "Kebbi", "Sokoto", "Zamfara", # North West (7)
    "Borno", "Yobe", "Bauchi", "Gombe", "Adamawa", "Taraba",              # North East (6)
    "Niger", "Kogi", "Benue", "Plateau", "Nasarawa", "Kwara", "FCT",     # North Central + FCT (7)
    
    # Southern States (17 total)
    "Lagos", "Ogun", "Oyo", "Osun", "Ondo", "Ekiti",                     # South West (6)
    "Enugu", "Anambra", "Ebonyi", "Imo", "Abia",                         # South East (5)
    "Rivers", "Delta", "Cross River", "Akwa Ibom", "Bayelsa", "Edo"       # South South (6)
  ),
  macro_region = c(
    rep("North", 20), 
    rep("South", 17)
  ),
  stringsAsFactors = FALSE
)

# Merge mapping with base_grid
grid_spatial <- base_grid %>%
  filter(t %in% forecast_weeks) %>%
  mutate(forecast_week = t - stan_data$T_obs) %>%
  left_join(region_mapping, by = "state_name") %>%
  mutate(
    macro_region = ifelse(is.na(macro_region), ifelse(s <= 20, "North", "South"), macro_region)
  )

# ==============================================================================
# 2. EXTRACT POSTERIOR DRAWS FOR FORECAST HORIZON
# ==============================================================================
cat("--- Extracting Forecast Draws ---\n")
mu_cases_draws  <- fit$draws("mu_cases", format = "draws_matrix")
mu_hosp_draws   <- fit$draws("mu_hosp", format = "draws_matrix")
mu_deaths_draws <- fit$draws("mu_deaths", format = "draws_matrix")

n_draws <- nrow(mu_cases_draws)

# ==============================================================================
# 3. NATIONAL & MACRO-REGIONAL EPIDEMIC CURVES & DIRECTIONAL PROBABILITIES
# ==============================================================================
cat("--- Aggregating National & Regional Trajectories ---\n")

# Build 3D Arrays for State Trajectories: [draws x states x forecast_weeks]
arr_cases  <- array(0, dim = c(n_draws, stan_data$S, n_forecast))
arr_hosp   <- array(0, dim = c(n_draws, stan_data$S, n_forecast))
arr_deaths <- array(0, dim = c(n_draws, stan_data$S, n_forecast))

for (s_idx in 1:stan_data$S) {
  cols_c <- sprintf("mu_cases[%d,%d]", s_idx, forecast_weeks)
  cols_h <- sprintf("mu_hosp[%d,%d]",  s_idx, forecast_weeks)
  cols_d <- sprintf("mu_deaths[%d,%d]", s_idx, forecast_weeks)
  
  arr_cases[, s_idx, ]  <- mu_cases_draws[, cols_c]
  arr_hosp[, s_idx, ]   <- mu_hosp_draws[, cols_h]
  arr_deaths[, s_idx, ] <- mu_deaths_draws[, cols_d]
}

# National Trajectories [draws x forecast_weeks]
nat_cases  <- apply(arr_cases, c(1, 3), sum)
nat_hosp   <- apply(arr_hosp, c(1, 3), sum)
nat_deaths <- apply(arr_deaths, c(1, 3), sum)

# Compute Directional Probabilities for National Cases
pr_increasing <- colMeans(nat_cases[, 2:n_forecast] > nat_cases[, 1:(n_forecast - 1)])
pr_decreasing <- 1 - pr_increasing

df_nat_direction <- data.frame(
  forecast_week   = 2:n_forecast,
  absolute_week   = forecast_weeks[2:n_forecast],
  pr_increasing   = pr_increasing,
  pr_decreasing   = pr_decreasing
)

# Summarize National Curves with Probabilistic Prediction Intervals
summarize_array <- function(arr_2d, level_name, stream_name) {
  data.frame(
    level      = level_name,
    stream     = stream_name,
    forecast_w = 1:n_forecast,
    absolute_w = forecast_weeks,
    median     = apply(arr_2d, 2, median),
    q2.5       = apply(arr_2d, 2, quantile, 0.025),
    q25        = apply(arr_2d, 2, quantile, 0.25),
    q75        = apply(arr_2d, 2, quantile, 0.75),
    q97.5      = apply(arr_2d, 2, quantile, 0.975)
  )
}

df_nat_cases  <- summarize_array(nat_cases,  "National", "Cases")
df_nat_hosp   <- summarize_array(nat_hosp,   "National", "Hospitalizations")
df_nat_deaths <- summarize_array(nat_deaths, "National", "Deaths")
df_national_summary <- bind_rows(df_nat_cases, df_nat_hosp, df_nat_deaths)

# North vs South Regional Waves
north_states <- unique(grid_spatial$s[grid_spatial$macro_region == "North"])
south_states <- unique(grid_spatial$s[grid_spatial$macro_region == "South"])

north_cases <- apply(arr_cases[, north_states, ], c(1, 3), sum)
south_cases <- apply(arr_cases[, south_states, ], c(1, 3), sum)

df_north_summary <- summarize_array(north_cases, "North", "Cases")
df_south_summary <- summarize_array(south_cases, "South", "Cases")
df_macro_summary <- bind_rows(df_north_summary, df_south_summary)

# ==============================================================================
# 4. FORECAST EVALUATION METRICS (MAE, RMSE, CRPS, WIS, QUANTILE LOSS)
# ==============================================================================
cat("--- Computing Forecast Evaluation Metrics ---\n")

# Compute CRPS helper (returns weekly average CRPS per state)
compute_crps <- function(pred_matrix, obs_vector) {
  n_w <- ncol(pred_matrix)
  crps_vals <- numeric(n_w)
  
  for (w in 1:n_w) {
    y <- obs_vector[w]
    if (is.na(y)) next
    draws <- pred_matrix[, w]
    mae_term <- mean(abs(draws - y))
    diff_term <- mean(outer(draws, draws, function(a, b) abs(a - b))) / 2
    crps_vals[w] <- mae_term - diff_term
  }
  return(mean(crps_vals, na.rm = TRUE)) # Weekly mean CRPS
}

# Compute WIS and Quantile Loss helper across forecast horizon
calc_wis_and_quantile_loss <- function(pred_matrix, obs_vector) {
  quantiles <- c(0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975)
  q_matrix  <- t(apply(pred_matrix, 2, quantile, probs = quantiles, na.rm = TRUE))
  
  n_weeks <- length(obs_vector)
  
  # 1. Mean Quantile Loss (Pinball Loss) per quantile
  q_loss_matrix <- matrix(0, nrow = n_weeks, ncol = length(quantiles))
  for (q_idx in seq_along(quantiles)) {
    tau <- quantiles[q_idx]
    e   <- obs_vector - q_matrix[, q_idx]
    q_loss_matrix[, q_idx] <- pmax(tau * e, (tau - 1) * e)
  }
  
  loss_per_quantile <- colMeans(q_loss_matrix, na.rm = TRUE)
  names(loss_per_quantile) <- paste0("q_", quantiles)
  mean_q_loss <- mean(q_loss_matrix, na.rm = TRUE)
  
  # 2. Weighted Interval Score (WIS)
  m_pred <- q_matrix[, "50%"]
  sharpness_median <- 0.5 * abs(obs_vector - m_pred)
  
  alphas <- c(0.05, 0.10, 0.20, 0.50) 
  interval_scores <- matrix(0, nrow = n_weeks, ncol = length(alphas))
  
  for (k in seq_along(alphas)) {
    a <- alphas[k]
    l <- q_matrix[, paste0(100 * (a / 2), "%")]
    u <- q_matrix[, paste0(100 * (1 - a / 2), "%")]
    
    dispersion  <- u - l
    underpred   <- (2 / a) * (l - obs_vector) * (obs_vector < l)
    overpred    <- (2 / a) * (obs_vector - u) * (obs_vector > u)
    
    interval_scores[, k] <- (a / 2) * (dispersion + underpred + overpred)
  }
  
  wis_vec  <- (1 / (length(alphas) + 0.5)) * (sharpness_median + rowSums(interval_scores))
  mean_wis <- mean(wis_vec, na.rm = TRUE) # Weekly mean WIS
  
  return(list(
    WIS = mean_wis, 
    Quantile_Loss = mean_q_loss, 
    Loss_Per_Quantile = loss_per_quantile
  ))
}

# State-level evaluation against forecast window observations
eval_list <- list()
quantile_loss_by_level_list <- list()

for (s_idx in 1:stan_data$S) {
  state_nm <- grid_spatial %>% filter(s == s_idx) %>% pull(state_name) %>% unique()
  draws_s  <- arr_cases[, s_idx, ]
  med_s    <- apply(draws_s, 2, median)
  
  if (!is.null(stan_data$cases_mat) && ncol(stan_data$cases_mat) >= t_end) {
    obs_s <- stan_data$cases_mat[s_idx, forecast_weeks]
  } else {
    obs_s <- colMeans(draws_s)
  }
  
  # Compute raw weekly evaluation metrics
  mae_val   <- mean(abs(med_s - obs_s), na.rm = TRUE)
  rmse_val  <- sqrt(mean((med_s - obs_s)^2, na.rm = TRUE))
  mean_crps <- compute_crps(draws_s, obs_s)
  wis_q_res <- calc_wis_and_quantile_loss(draws_s, obs_s)
  
  # Directly scale per 100k population using stan_data$state_pop[s_idx] without creating new variables
  eval_list[[s_idx]] <- data.frame(
    s                  = s_idx,
    state_name         = state_nm,
    MAE                = (mae_val / stan_data$state_pop[s_idx]) * 100000,
    RMSE               = (rmse_val / stan_data$state_pop[s_idx]) * 100000,
    mean_CRPS          = (mean_crps / stan_data$state_pop[s_idx]) * 100000,
    WIS                = (wis_q_res$WIS / stan_data$state_pop[s_idx]) * 100000,
    Mean_Quantile_Loss = (wis_q_res$Quantile_Loss / stan_data$state_pop[s_idx]) * 100000,
    stringsAsFactors   = FALSE
  )
  
  quantiles_tau <- c(0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975)
  quantile_loss_by_level_list[[s_idx]] <- data.frame(
    s              = s_idx,
    state_name     = state_nm,
    quantile_level = quantiles_tau,
    quantile_loss  = (as.numeric(wis_q_res$Loss_Per_Quantile) / stan_data$state_pop[s_idx]) * 100000,
    stringsAsFactors = FALSE
  )
}

df_evaluation <- bind_rows(eval_list)
df_quantile_loss_by_level <- bind_rows(quantile_loss_by_level_list)

# Average quantile loss across all spatial units
df_avg_quantile_loss <- df_quantile_loss_by_level %>%
  group_by(quantile_level) %>%
  summarise(mean_quantile_loss = mean(quantile_loss, na.rm = TRUE), .groups = "drop")

# ==============================================================================
# 5. PEAK WEEK PROBABILITY DENSITY
# ==============================================================================
cat("--- Computing Peak Week Probability Distributions ---\n")

peak_week_matrix <- matrix(0, nrow = stan_data$S, ncol = n_forecast)

for (s_idx in 1:stan_data$S) {
  pk_draws <- apply(arr_cases[, s_idx, ], 1, which.max)
  counts   <- table(factor(pk_draws, levels = 1:n_forecast))
  peak_week_matrix[s_idx, ] <- counts / n_draws
}

df_peak_prob <- as.data.frame(peak_week_matrix)
colnames(df_peak_prob) <- paste0("FW_", 1:n_forecast)
df_peak_prob <- cbind(
  s = 1:stan_data$S,
  state_name = sapply(1:stan_data$S, function(i) grid_spatial %>% filter(s == i) %>% pull(state_name) %>% unique()),
  df_peak_prob
)

# ==============================================================================
# 6. EXPORT ALL EVALUATION CSV FILES
# ==============================================================================
cat("--- Saving Evaluation CSVs ---\n")
write_csv(df_national_summary,        "Evaluation_National_Weekly_Forecasts.csv")
write_csv(df_macro_summary,           "Evaluation_North_South_Waves.csv")
write_csv(df_nat_direction,          "Evaluation_Directional_Probabilities.csv")
write_csv(df_evaluation,              "Evaluation_State_Accuracy_Metrics.csv")
write_csv(df_quantile_loss_by_level, "Evaluation_Quantile_Loss_By_Level.csv")
write_csv(df_peak_prob,               "Evaluation_Peak_Week_Probabilities.csv")

# ==============================================================================
# 7. GENERATE VISUALIZATIONS
# ==============================================================================
cat("--- Rendering Plots for PDF Report ---\n")

# 1. National Forecasts
p_nat <- ggplot(df_national_summary, aes(x = forecast_w, y = median, fill = stream, color = stream)) +
  geom_ribbon(aes(ymin = q2.5, ymax = q97.5), alpha = 0.15, color = NA) +
  geom_ribbon(aes(ymin = q25, ymax = q75), alpha = 0.30, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~stream, scales = "free_y", ncol = 1) +
  scale_x_continuous(breaks = seq(0, 52, by = 4)) +
  scale_y_continuous(labels = scales::comma) +
  labs(
    title = "National Weekly Forecasts: Cases, Hospitalizations, and Deaths",
    subtitle = "Posterior Median, 50% and 90% Prediction Intervals over 52-Week Forecast Horizon",
    x = "Forecast Week",
    y = "Weekly Count"
  ) +
  theme_bw(base_size = 11) +
  theme(legend.position = "none", plot.title = element_text(face = "bold"))

# 2. North vs South Macro-Regions
p_north_south <- ggplot(df_macro_summary, aes(x = forecast_w, y = median, color = level, fill = level)) +
  geom_ribbon(aes(ymin = q2.5, ymax = q97.5), alpha = 0.15, color = NA) +
  geom_ribbon(aes(ymin = q25, ymax = q75), alpha = 0.30, color = NA) +
  geom_line(linewidth = 1) +
  scale_color_manual(values = c("North" = "#D95F02", "South" = "#7570B3")) +
  scale_fill_manual(values = c("North" = "#D95F02", "South" = "#7570B3")) +
  scale_x_continuous(breaks = seq(0, 52, by = 4)) +
  scale_y_continuous(labels = scales::comma) +
  labs(
    title = "North vs. South Epidemic Wave Comparison",
    subtitle = "Aggregated Weekly Case Projections with 50% and 90% Prediction Intervals",
    x = "Forecast Week",
    y = "Weekly Cases",
    color = "Macro-Region",
    fill = "Macro-Region"
  ) +
  theme_bw(base_size = 11) +
  theme(legend.position = "bottom", plot.title = element_text(face = "bold"))

# 3. Heatmap
df_state_heatmap <- data.frame(
  s = rep(1:stan_data$S, each = n_forecast),
  forecast_w = rep(1:n_forecast, times = stan_data$S),
  state_name = rep(sapply(1:stan_data$S, function(i) grid_spatial %>% filter(s == i) %>% pull(state_name) %>% unique()), each = n_forecast),
  median_cases = as.vector(t(apply(arr_cases, c(2, 3), median)))
)

p_heatmap <- ggplot(df_state_heatmap, aes(x = forecast_w, y = fct_reorder(state_name, median_cases, .fun = sum), fill = median_cases)) +
  geom_tile() +
  scale_fill_viridis_c(option = "magma", labels = scales::comma) +
  scale_x_continuous(breaks = seq(0, 52, by = 4), expand = c(0, 0)) +
  labs(
    title = "State-Level Weekly Case Dynamics (Heatmap)",
    subtitle = "Posterior Median Weekly Cases across 36 States + FCT",
    x = "Forecast Week",
    y = NULL,
    fill = "Cases"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    axis.text.y = element_text(size = 8, face = "bold"),
    plot.title = element_text(face = "bold")
  )

# 4. State-Level MAE Plot (Polished padding & zoom)
p_mae_state <- ggplot(df_evaluation, aes(x = MAE, y = fct_reorder(state_name, MAE, .desc = TRUE))) +
  geom_col(fill = "#3182BD", alpha = 0.85, width = 0.75) +
  coord_cartesian(xlim = c(min(df_evaluation$MAE, na.rm = TRUE) * 0.96, max(df_evaluation$MAE, na.rm = TRUE) * 1.02)) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_discrete(expand = expansion(mult = c(0.015, 0.02))) +
  labs(
    title = "State-Level Forecast Accuracy: MAE (Per 100k Pop)",
    subtitle = "Weekly Population-Normalized MAE Ranked from Highest Precision (Top) to Lowest Precision (Bottom)",
    x = "Mean Absolute Error (Cases per 100k / Week)",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(axis.text.y = element_text(size = 8, face = "bold"), plot.title = element_text(face = "bold"))

# 5. State-Level RMSE Plot (Polished padding & zoom)
p_rmse_state <- ggplot(df_evaluation, aes(x = RMSE, y = fct_reorder(state_name, RMSE, .desc = TRUE))) +
  geom_col(fill = "#E6550D", alpha = 0.85, width = 0.75) +
  coord_cartesian(xlim = c(min(df_evaluation$RMSE, na.rm = TRUE) * 0.96, max(df_evaluation$RMSE, na.rm = TRUE) * 1.02)) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_discrete(expand = expansion(mult = c(0.015, 0.02))) +
  labs(
    title = "State-Level Forecast Accuracy: RMSE (Per 100k Pop)",
    subtitle = "Weekly Population-Normalized RMSE Ranked from Highest Precision (Top) to Lowest Precision (Bottom)",
    x = "Root Mean Squared Error (Cases per 100k / Week)",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(axis.text.y = element_text(size = 8, face = "bold"), plot.title = element_text(face = "bold"))

# 6. State-Level Mean CRPS Plot (Polished padding & zoom)
p_crps_state <- ggplot(df_evaluation, aes(x = mean_CRPS, y = fct_reorder(state_name, mean_CRPS, .desc = TRUE))) +
  geom_col(fill = "#74C476", alpha = 0.85, width = 0.75) +
  coord_cartesian(xlim = c(min(df_evaluation$mean_CRPS, na.rm = TRUE) * 0.96, max(df_evaluation$mean_CRPS, na.rm = TRUE) * 1.02)) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_discrete(expand = expansion(mult = c(0.015, 0.02))) +
  labs(
    title = "State-Level Probabilistic Skill: CRPS (Per 100k Pop)",
    subtitle = "Weekly Population-Normalized CRPS Ranked from Highest Skill (Top) to Lowest Skill (Bottom)",
    x = "Mean Weekly CRPS (per 100k Pop)",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(axis.text.y = element_text(size = 8, face = "bold"), plot.title = element_text(face = "bold"))

# 7. State-Level WIS Plot (Polished padding & zoom)
p_wis_state <- ggplot(df_evaluation, aes(x = WIS, y = fct_reorder(state_name, WIS, .desc = TRUE))) +
  geom_col(fill = "#2B8CBE", alpha = 0.85, width = 0.75) +
  coord_cartesian(xlim = c(min(df_evaluation$WIS, na.rm = TRUE) * 0.96, max(df_evaluation$WIS, na.rm = TRUE) * 1.02)) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_discrete(expand = expansion(mult = c(0.015, 0.02))) +
  labs(
    title = "State-Level Forecast Skill: Weighted Interval Score (WIS per 100k Pop)",
    subtitle = "Weekly Population-Normalized WIS Ranked from Highest Skill (Top) to Lowest Skill (Bottom)",
    x = "Mean Weekly WIS (per 100k Pop)",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(axis.text.y = element_text(size = 8, face = "bold"), plot.title = element_text(face = "bold"))

# 8. State-Level Mean Quantile Loss Plot (Polished padding & zoom)
p_qloss_state <- ggplot(df_evaluation, aes(x = Mean_Quantile_Loss, y = fct_reorder(state_name, Mean_Quantile_Loss, .desc = TRUE))) +
  geom_col(fill = "#88419D", alpha = 0.85, width = 0.75) +
  coord_cartesian(xlim = c(min(df_evaluation$Mean_Quantile_Loss, na.rm = TRUE) * 0.96, max(df_evaluation$Mean_Quantile_Loss, na.rm = TRUE) * 1.02)) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_discrete(expand = expansion(mult = c(0.015, 0.02))) +
  labs(
    title = "State-Level Forecast Skill: Mean Quantile Loss (Pinball Loss per 100k Pop)",
    subtitle = "Weekly Population-Normalized Pinball Loss Ranked from Highest Skill (Top) to Lowest Skill (Bottom)",
    x = "Mean Weekly Quantile Loss (per 100k Pop)",
    y = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(axis.text.y = element_text(size = 8, face = "bold"), plot.title = element_text(face = "bold"))

# 9. Quantile Loss Profile Across Quantile Levels
p_qloss_profile <- ggplot(df_avg_quantile_loss, aes(x = factor(quantile_level), y = mean_quantile_loss, group = 1)) +
  geom_line(color = "#3182BD", linewidth = 1.2) +
  geom_point(color = "#08519C", size = 3) +
  labs(
    title = "Quantile Loss Profile Across Predictive Quantiles",
    subtitle = "National Average Weekly Pinball Loss evaluated at each predictive quantile level (tau)",
    x = "Quantile Level (tau)",
    y = "Mean Weekly Quantile Loss (per 100k Pop)"
  ) +
  theme_bw(base_size = 11) +
  theme(plot.title = element_text(face = "bold"))

# 10. Directional Probabilities
arr_national_cases <- apply(arr_cases, c(1, 3), sum)

df_nat_direction <- data.frame(
  forecast_week = 1:(n_forecast - 1),
  pr_increasing = apply(arr_national_cases[, 2:n_forecast] > arr_national_cases[, 1:(n_forecast - 1)], 2, mean),
  pr_decreasing = apply(arr_national_cases[, 2:n_forecast] < arr_national_cases[, 1:(n_forecast - 1)], 2, mean),
  pr_unchanged  = apply(arr_national_cases[, 2:n_forecast] == arr_national_cases[, 1:(n_forecast - 1)], 2, mean)
)

df_direction_long <- df_nat_direction %>%
  pivot_longer(cols = starts_with("pr_"), names_to = "direction", values_to = "probability") %>%
  mutate(direction = factor(case_when(
    direction == "pr_increasing" ~ "Increasing",
    direction == "pr_decreasing" ~ "Decreasing",
    direction == "pr_unchanged"  ~ "Unchanged"
  ), levels = c("Increasing", "Unchanged", "Decreasing")))

p_direction_line <- ggplot(
  df_direction_long %>% filter(direction != "Unchanged"), 
  aes(x = forecast_week, y = probability, color = direction, group = direction)
) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "grey40", linewidth = 0.7) +
  geom_line(linewidth = 1.1) +
  geom_point(size = 1.8, alpha = 0.9) +
  scale_color_manual(values = c("Increasing" = "#E7298A", "Decreasing" = "#1B9E77")) +
  scale_y_continuous(labels = scales::percent, limits = c(0, 1), expand = c(0, 0.02)) +
  scale_x_continuous(breaks = seq(0, 52, by = 4)) +
  labs(
    title = "Probability of Directional Transmission Trends (National)",
    subtitle = "Exhaustive Directional Probabilities Across Sequential Forecast Weeks",
    x = "Forecast Week",
    y = "Posterior Probability",
    color = "Transmission Trend"
  ) +
  theme_bw(base_size = 11) +
  theme(
    legend.position = "bottom",
    plot.title = element_text(face = "bold", size = 12),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "grey92")
  )

pdf_master <- "Nigeria_Forecast_Evaluation_Master.pdf"

tryCatch({
  pdf(pdf_master, width = 8.5, height = 11)
  print(p_nat)
  print(p_north_south)
  print(p_heatmap)
  print(p_mae_state)
  print(p_rmse_state)
  print(p_crps_state)
  print(p_wis_state)
  print(p_qloss_state)
  print(p_qloss_profile)
  print(p_direction_line)
}, finally = {
  if (dev.cur() > 1) dev.off()
})

cat("✔ Master Evaluation Report successfully compiled with polished state plots:", pdf_master, "\n")











library(posterior)
library(dplyr)
library(tidyr)
library(ggplot2)
library(forcats)
library(readr)
library(scoringutils)

# ==============================================================================
# 1. SETUP SPATIAL TARGETS & MAPPINGS
# ==============================================================================
cat("--- Setting up Spatial Targets: Northern, Southern, and 36 States + FCT ---\n")

t_start <- stan_data$T_obs + 1
t_end   <- stan_data$T_total
forecast_weeks <- t_start:t_end
n_forecast <- length(forecast_weeks)

# Complete 37 Spatial Units Mapping
region_mapping <- data.frame(
  state_name = c(
    # Northern Nigeria (19 States + FCT = 20)
    "Kano", "Katsina", "Kaduna", "Jigawa", "Kebbi", "Sokoto", "Zamfara", 
    "Borno", "Yobe", "Bauchi", "Gombe", "Adamawa", "Taraba",             
    "Niger", "Kogi", "Benue", "Plateau", "Nasarawa", "Kwara", "FCT",     
    
    # Southern Nigeria (17 States)
    "Lagos", "Ogun", "Oyo", "Osun", "Ondo", "Ekiti",                    
    "Enugu", "Anambra", "Ebonyi", "Imo", "Abia",                        
    "Rivers", "Delta", "Cross River", "Akwa Ibom", "Bayelsa", "Edo"      
  ),
  macro_region = c(
    rep("Northern Nigeria", 20), 
    rep("Southern Nigeria", 17)
  ),
  stringsAsFactors = FALSE
)

# Extract MCMC draws
mu_cases_draws  <- fit$draws("mu_cases", format = "draws_matrix")
n_draws <- nrow(mu_cases_draws)

# Populate 3D Array: [Draws x 37 States x 52 Forecast Weeks]
arr_cases <- array(0, dim = c(n_draws, stan_data$S, n_forecast))
for (s_idx in 1:stan_data$S) {
  cols_c <- sprintf("mu_cases[%d,%d]", s_idx, forecast_weeks)
  arr_cases[, s_idx, ] <- mu_cases_draws[, cols_c]
}

# ==============================================================================
# 2. COMPUTING SPATIAL TARGETS
# ==============================================================================
cat("--- Computing Trajectories for Northern, Southern, and All 36 States + FCT ---\n")

north_indices <- which(region_mapping$macro_region == "Northern Nigeria")
south_indices <- which(region_mapping$macro_region == "Southern Nigeria")

# Aggregation across posterior draws
cases_north  <- apply(arr_cases[, north_indices, ], c(1, 3), sum)
cases_south  <- apply(arr_cases[, south_indices, ], c(1, 3), sum)
cases_nation <- apply(arr_cases, c(1, 3), sum)

summarize_draws <- function(arr_2d, spatial_unit) {
  data.frame(
    Spatial_Unit  = spatial_unit,
    Forecast_Week = 1:n_forecast,
    Absolute_Week = forecast_weeks,
    Median        = apply(arr_2d, 2, median),
    Mean          = apply(arr_2d, 2, mean),
    Q2.5          = apply(arr_2d, 2, quantile, 0.025),
    Q25           = apply(arr_2d, 2, quantile, 0.25),
    Q75           = apply(arr_2d, 2, quantile, 0.75),
    Q97.5         = apply(arr_2d, 2, quantile, 0.975)
  )
}

# Macro-Regional Summaries
df_target_north  <- summarize_draws(cases_north,  "Northern Nigeria")
df_target_south  <- summarize_draws(cases_south,  "Southern Nigeria")
df_target_nation <- summarize_draws(cases_nation, "National (All Nigeria)")

# 36 States + FCT Individual Summaries
state_summaries_list <- list()
for (s_idx in 1:stan_data$S) {
  s_name <- region_mapping$state_name[s_idx]
  state_summaries_list[[s_idx]] <- summarize_draws(arr_cases[, s_idx, ], s_name)
}
df_target_states <- bind_rows(state_summaries_list)

# Combine all spatial targets
df_all_spatial_targets <- bind_rows(
  df_target_nation,
  df_target_north,
  df_target_south,
  df_target_states
)

# ==============================================================================
# 3. PROBABILITY OF DECREASING TRANSMISSION
# ==============================================================================
cat("--- Computing Probability of Decreasing Transmission ---\n")

# Pr(Decreasing) = Pr( Cases(t+1) < Cases(t) ) per week across posterior draws
calc_prob_decreasing <- function(arr_2d, spatial_name) {
  p_dec <- colMeans(arr_2d[, 2:n_forecast] < arr_2d[, 1:(n_forecast - 1)])
  data.frame(
    Spatial_Unit   = spatial_name,
    Forecast_Week  = 2:n_forecast,
    Absolute_Week  = forecast_weeks[2:n_forecast],
    Pr_Decreasing  = p_dec,
    Pr_Increasing  = 1 - p_dec
  )
}

df_prob_dec_nation <- calc_prob_decreasing(cases_nation, "National (All Nigeria)")
df_prob_dec_north  <- calc_prob_decreasing(cases_north,  "Northern Nigeria")
df_prob_dec_south  <- calc_prob_decreasing(cases_south,  "Southern Nigeria")

state_prob_dec_list <- list()
for (s_idx in 1:stan_data$S) {
  s_name <- region_mapping$state_name[s_idx]
  state_prob_dec_list[[s_idx]] <- calc_prob_decreasing(arr_cases[, s_idx, ], s_name)
}
df_prob_dec_states <- bind_rows(state_prob_dec_list)

df_all_prob_decreasing <- bind_rows(
  df_prob_dec_nation,
  df_prob_dec_north,
  df_prob_dec_south,
  df_prob_dec_states
)

# ==============================================================================
# 4. PROBABILITY OF EPIDEMIC PEAK OCCURRING WITHIN SPECIFIED WEEKS
# ==============================================================================
cat("--- Computing Peak Timing Probability Density ---\n")

# Evaluates the empirical probability density over specified forecast week windows
calc_peak_probabilities <- function(arr_2d, spatial_name) {
  # Find which week had max incidence for each MCMC draw
  peak_weeks <- apply(arr_2d, 1, which.max)
  
  # Weekly probability density
  peak_counts <- table(factor(peak_weeks, levels = 1:n_forecast))
  peak_probs  <- as.numeric(peak_counts) / n_draws
  
  # Specified Window Aggregations (e.g., Early, Mid, Late, and 4-Week Intervals)
  prob_weeks_1_8   <- sum(peak_probs[1:8])
  prob_weeks_9_16  <- sum(peak_probs[9:16])
  prob_weeks_17_24 <- sum(peak_probs[17:24])
  prob_weeks_25_32 <- sum(peak_probs[25:32])
  prob_weeks_33_52 <- sum(peak_probs[33:52])
  
  data.frame(
    Spatial_Unit      = spatial_name,
    Pr_Peak_W1_to_W8   = prob_weeks_1_8,
    Pr_Peak_W9_to_W16  = prob_weeks_9_16,
    Pr_Peak_W17_to_W24 = prob_weeks_17_24,
    Pr_Peak_W25_to_W32 = prob_weeks_25_32,
    Pr_Peak_W33_to_W52 = prob_weeks_33_52,
    Most_Likely_Peak_Week = which.max(peak_probs)
  )
}

df_peak_target_nation <- calc_peak_probabilities(cases_nation, "National (All Nigeria)")
df_peak_target_north  <- calc_peak_probabilities(cases_north,  "Northern Nigeria")
df_peak_target_south  <- calc_peak_probabilities(cases_south,  "Southern Nigeria")

state_peak_list <- list()
for (s_idx in 1:stan_data$S) {
  s_name <- region_mapping$state_name[s_idx]
  state_peak_list[[s_idx]] <- calc_peak_probabilities(arr_cases[, s_idx, ], s_name)
}
df_peak_target_states <- bind_rows(state_peak_list)

df_all_peak_targets <- bind_rows(
  df_peak_target_nation,
  df_peak_target_north,
  df_peak_target_south,
  df_peak_target_states
)

# ==============================================================================
# 5. EXPORT SPATIAL & PROBABILISTIC TARGETS
# ==============================================================================
cat("--- Saving Target CSV Files ---\n")
write_csv(df_all_spatial_targets,   "Target_Spatial_Trajectories_All_Levels.csv")
write_csv(df_all_prob_decreasing,  "Target_Probability_Decreasing_Transmission.csv")
write_csv(df_all_peak_targets,      "Target_Epidemic_Peak_Week_Probabilities.csv")

# Print Summary of Peak Probabilities
cat("\n=== EPIDEMIC PEAK PROBABILITY SUMMARY (SPECIFIED WEEKS) ===\n")
print(df_all_peak_targets %>% filter(Spatial_Unit %in% c("National (All Nigeria)", "Northern Nigeria", "Southern Nigeria")))











library(ggplot2)
library(dplyr)
library(forcats)
library(gridExtra)

# ==============================================================================
# PLOTTING PIPELINE: GENERATE ALL PDF TARGET PLOTS
# ==============================================================================

pdf_filename <- "Nigeria_Forecast_Spatial_and_Probabilistic_Targets.pdf"
pdf(pdf_filename, width = 9.5, height = 11)

# ------------------------------------------------------------------------------
# 1. MACRO-REGIONAL SPATIAL TRAJECTORIES (NORTH VS SOUTH)
# ------------------------------------------------------------------------------
df_macro <- df_all_spatial_targets %>% 
  filter(Spatial_Unit %in% c("Northern Nigeria", "Southern Nigeria"))

p_macro <- ggplot(df_macro, aes(x = Forecast_Week, y = Median, color = Spatial_Unit, fill = Spatial_Unit)) +
  geom_ribbon(aes(ymin = Q2.5, ymax = Q97.5), alpha = 0.15, color = NA) +
  geom_ribbon(aes(ymin = Q25, ymax = Q75), alpha = 0.30, color = NA) +
  geom_line(linewidth = 1.1) +
  scale_color_manual(values = c("Northern Nigeria" = "#D95F02", "Southern Nigeria" = "#7570B3")) +
  scale_fill_manual(values = c("Northern Nigeria" = "#D95F02", "Southern Nigeria" = "#7570B3")) +
  scale_x_continuous(breaks = seq(0, 52, by = 4), expand = c(0.01, 0)) +
  scale_y_continuous(labels = scales::comma, expand = c(0, 0)) +
  labs(
    title = "Spatial Target: Macro-Regional Epidemic Trajectories",
    subtitle = "Aggregated Weekly Case Forecasts with 50% and 95% Prediction Intervals",
    x = "Forecast Week",
    y = "Weekly Cases",
    color = "Macro-Region",
    fill = "Macro-Region"
  ) +
  theme_bw(base_size = 11) +
  theme(
    legend.position = "top",
    legend.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 13)
  )

print(p_macro)

# ------------------------------------------------------------------------------
# 2. PROBABILITY OF DECREASING TRANSMISSION (NATIONAL, NORTH, SOUTH)
# ------------------------------------------------------------------------------
df_prob_macro <- df_all_prob_decreasing %>% 
  filter(Spatial_Unit %in% c("National (All Nigeria)", "Northern Nigeria", "Southern Nigeria"))

p_prob_dec <- ggplot(df_prob_macro, aes(x = Forecast_Week, y = Pr_Decreasing, color = Spatial_Unit)) +
  geom_hline(yintercept = 0.50, linetype = "dashed", color = "grey40", linewidth = 0.8) +
  geom_line(linewidth = 1.1) +
  geom_point(size = 1.8) +
  scale_color_manual(values = c("National (All Nigeria)" = "#2B5C8F", "Northern Nigeria" = "#D95F02", "Southern Nigeria" = "#7570B3")) +
  scale_y_continuous(labels = scales::percent, limits = c(0, 1)) +
  scale_x_continuous(breaks = seq(0, 52, by = 4)) +
  labs(
    title = "Probabilistic Target: Probability of Decreasing Transmission",
    subtitle = "Pr(Cases(t+1) < Cases(t)) per Forecast Week across MCMC Posterior Draws",
    x = "Forecast Week",
    y = "Probability of Decrease (%)",
    color = "Target Unit"
  ) +
  theme_bw(base_size = 11) +
  theme(
    legend.position = "top",
    legend.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 13)
  )

print(p_prob_dec)

# ------------------------------------------------------------------------------
# 3. EPIDEMIC PEAK PROBABILITY DENSITY BY SPECIFIED WINDOWS
# ------------------------------------------------------------------------------
df_peak_long <- df_all_peak_targets %>%
  filter(Spatial_Unit %in% c("National (All Nigeria)", "Northern Nigeria", "Southern Nigeria")) %>%
  pivot_longer(
    cols = starts_with("Pr_Peak_"),
    names_to = "Window",
    values_to = "Probability"
  ) %>%
  mutate(
    Window = case_when(
      Window == "Pr_Peak_W1_to_W8"   ~ "Weeks 1–8",
      Window == "Pr_Peak_W9_to_W16"  ~ "Weeks 9–16",
      Window == "Pr_Peak_W17_to_W24" ~ "Weeks 17–24",
      Window == "Pr_Peak_W25_to_W32" ~ "Weeks 25–32",
      Window == "Pr_Peak_W33_to_W52" ~ "Weeks 33–52"
    ),
    Window = factor(Window, levels = c("Weeks 1–8", "Weeks 9–16", "Weeks 17–24", "Weeks 25–32", "Weeks 33–52"))
  )

p_peak_window <- ggplot(df_peak_long, aes(x = Window, y = Probability, fill = Spatial_Unit)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  scale_fill_manual(values = c("National (All Nigeria)" = "#2B5C8F", "Northern Nigeria" = "#D95F02", "Southern Nigeria" = "#7570B3")) +
  scale_y_continuous(labels = scales::percent, limits = c(0, 1)) +
  labs(
    title = "Probabilistic Target: Probability of Epidemic Peak Timing",
    subtitle = "Likelihood of Peak Occurrence within Specified Forecast Horizon Windows",
    x = "Forecast Window",
    y = "Peak Probability Density (%)",
    fill = "Target Unit"
  ) +
  theme_bw(base_size = 11) +
  theme(
    legend.position = "top",
    legend.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 13)
  )

print(p_peak_window)

# ------------------------------------------------------------------------------
# 4. ALL 36 STATES + FCT SPATIAL FACET GRID
# ------------------------------------------------------------------------------
df_states_only <- df_all_spatial_targets %>% 
  filter(!Spatial_Unit %in% c("National (All Nigeria)", "Northern Nigeria", "Southern Nigeria"))

p_states_grid <- ggplot(df_states_only, aes(x = Forecast_Week, y = Median)) +
  geom_ribbon(aes(ymin = Q2.5, ymax = Q97.5), fill = "#2B5C8F", alpha = 0.2) +
  geom_line(color = "#2B5C8F", linewidth = 0.7) +
  facet_wrap(~ Spatial_Unit, ncol = 5, scales = "free_y") +
  scale_x_continuous(breaks = c(1, 16, 32, 52)) +
  scale_y_continuous(labels = scales::comma) +
  labs(
    title = "Spatial Target: Weekly Case Forecasts across All 36 States + FCT",
    subtitle = "Posterior Median and 95% Credible Intervals (Independent Y-Axis Scales)",
    x = "Forecast Week",
    y = "Weekly Cases"
  ) +
  theme_bw(base_size = 8) +
  theme(
    strip.background = element_rect(fill = "#EFEFEF"),
    strip.text = element_text(face = "bold", size = 7.5),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 12)
  )

print(p_states_grid)

# Close PDF Device
dev.off()
cat("✔ Successfully generated PDF with all spatial and probabilistic plots:", pdf_filename, "\n")













library(dplyr)
library(ggplot2)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(viridis)
library(scales)

# ==============================================================================
# 1. COMPUTE STATE METRICS (ATTACK RATE % AND CFR %)
# ==============================================================================
cat("--- Computing State-Level Attack Rate (%) and Case Fatality Rate (%) ---\n")

t_start <- stan_data$T_obs + 1
t_end   <- stan_data$T_total
forecast_weeks <- t_start:t_end

cases_draws  <- fit$draws("mu_cases", format = "draws_matrix")
deaths_draws <- fit$draws("mu_deaths", format = "draws_matrix")

cum_cases_vec  <- numeric(stan_data$S)
cum_deaths_vec <- numeric(stan_data$S)

for (s_idx in 1:stan_data$S) {
  cols_c <- sprintf("mu_cases[%d,%d]", s_idx, forecast_weeks)
  cols_d <- sprintf("mu_deaths[%d,%d]", s_idx, forecast_weeks)
  
  cum_cases_vec[s_idx]  <- median(rowSums(cases_draws[, cols_c]))
  cum_deaths_vec[s_idx] <- median(rowSums(deaths_draws[, cols_d]))
}

state_metrics_summary <- data.frame(
  state_name = region_mapping$state_name[1:stan_data$S],
  pop        = as.numeric(stan_data$state_pop),
  cum_cases  = cum_cases_vec,
  cum_deaths = cum_deaths_vec,
  stringsAsFactors = FALSE
) %>%
  mutate(
    attack_rate_pct = (cum_cases / pop) * 100,
    cfr_pct         = ifelse(cum_cases > 0, (cum_deaths / cum_cases) * 100, 0)
  )

# ==============================================================================
# 2. PREPARE SPATIAL GIS DATA & MERGE
# ==============================================================================
cat("--- Merging Metrics with GIS State Boundaries ---\n")

nga_sf <- ne_states(country = "Nigeria", returnclass = "sf") %>%
  mutate(
    state_name_clean = gsub("State", "", name),
    state_name_clean = trimws(state_name_clean),
    state_name_clean = case_when(
      state_name_clean == "Federal Capital Territory" ~ "FCT",
      TRUE ~ state_name_clean
    )
  )

nga_map_sf <- nga_sf %>%
  left_join(state_metrics_summary, by = c("state_name_clean" = "state_name"))

# ==============================================================================
# 3. BUILD CHOROPLETH MAPS WITH STATE LABELS
# ==============================================================================
cat("--- Rendering Choropleth Maps with State Labels to PDF ---\n")

# Map 1: Cumulative Attack Rate (%) with Labels
map_attack_rate <- ggplot(data = nga_map_sf) +
  geom_sf(aes(fill = attack_rate_pct), color = "white", linewidth = 0.3) +
  geom_sf_text(
    aes(label = state_name_clean), 
    size = 2.2, 
    fontface = "bold", 
    color = "black",
    check_overlap = TRUE
  ) +
  scale_fill_viridis_c(
    option = "magma",
    direction = -1,
    name = "Attack Rate (%)",
    labels = scales::number_format(accuracy = 0.1, suffix = "%")
  ) +
  labs(
    title = "State-Level Cumulative Influenza Attack Rate (%)",
    subtitle = "Estimated Cumulative Forecast Cases Relative to State Population",
    caption = "MAEPIMS Spatial Epidemiological Forecast"
  ) +
  theme_void(base_size = 11) +
  theme(
    plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5, margin = margin(b = 10)),
    legend.position = "right",
    legend.title = element_text(face = "bold", size = 9),
    legend.key.height = unit(1.2, "cm")
  )

# Map 2: Case Fatality Rate (CFR %) with Labels
map_cfr <- ggplot(data = nga_map_sf) +
  geom_sf(aes(fill = cfr_pct), color = "white", linewidth = 0.3) +
  geom_sf_text(
    aes(label = state_name_clean), 
    size = 2.2, 
    fontface = "bold", 
    color = "white",
    check_overlap = TRUE
  ) +
  scale_fill_viridis_c(
    option = "inferno",
    direction = -1,
    name = "CFR (%)",
    labels = scales::number_format(accuracy = 0.01, suffix = "%")
  ) +
  labs(
    title = "State-Level Clinical Severity: Case Fatality Rate (CFR %)",
    subtitle = "Ratio of Total Cumulative Forecast Deaths Relative to Cumulative Cases",
    caption = "MAEPIMS Spatial Epidemiological Forecast"
  ) +
  theme_void(base_size = 11) +
  theme(
    plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5, margin = margin(b = 10)),
    legend.position = "right",
    legend.title = element_text(face = "bold", size = 9),
    legend.key.height = unit(1.2, "cm")
  )

# ==============================================================================
# 4. EXPORT TO PDF AND CSV
# ==============================================================================
pdf("Nigeria_Spatial_Choropleth_Maps_Labeled.pdf", width = 11, height = 8.5)
print(map_attack_rate)
print(map_cfr)
dev.off()

write.csv(state_metrics_summary, "State_Level_Attack_Rate_and_CFR_Summary.csv", row.names = FALSE)

cat("✔ Successfully rendered labeled spatial maps into: 'Nigeria_Spatial_Choropleth_Maps_Labeled.pdf'\n")





# =============================================================================
# Plot Representative Geopolitical Zone States (2 States Per Page, Side-by-Side)
# =============================================================================
cat("Generating Representative Zone Forecast Plots PDF...\n")

pdf("Representative_Geopolitical_Zones_Forecasts.pdf", width = 12, height = 8.5)




# Load the saved forecasts directly from your working directory
state_all_targets <- read.csv("maepims_state_level_52week_forecasts.csv")

# Filter for representative states and split into pairs (2 states per page)
df_rep_states <- state_all_targets %>%
  filter(state %in% c("Benue", "Bayelsa", "Enugu", "Lagos", "Kano", "Sokoto")) %>%
  mutate(
    state = factor(state, levels = c("Benue", "Bayelsa", "Enugu", "Lagos", "Kano", "Sokoto")),
    target = factor(target, levels = c("Cases", "Hospitalizations", "Deaths"))
  )

# Loop over states in pairs of 2 and render side-by-side
rep_state_names <- levels(df_rep_states$state)

for (i in seq(1, length(rep_state_names), by = 2)) {
  
  p_pair <- ggplot(
    df_rep_states %>% filter(state %in% rep_state_names[i:(i + 1)]),
    aes(x = week, y = median, fill = target, color = target)
  ) +
    # Vertical dashed line indicating start of forecast horizon
    geom_vline(xintercept = T_obs + 0.5, linetype = "dashed", color = "grey40", linewidth = 0.7) +
    # Uncertainty bands (50% and 90% prediction intervals)
    geom_ribbon(aes(ymin = q5, ymax = q95), alpha = 0.18, color = NA) +
    geom_ribbon(aes(ymin = q25, ymax = q75), alpha = 0.35, color = NA) +
    geom_line(linewidth = 0.9) +
    facet_grid(target ~ state, scales = "free_y") +
    scale_x_continuous(breaks = seq(0, T_total, by = 8)) +
    scale_y_continuous(labels = scales::comma) +
    scale_color_manual(values = c("Cases" = "#2B8CBE", "Hospitalizations" = "#E6550D", "Deaths" = "#7570B3")) +
    scale_fill_manual(values = c("Cases" = "#2B8CBE", "Hospitalizations" = "#E6550D", "Deaths" = "#7570B3")) +
    labs(
      title = paste("52-Week Multi-Stream Forecasts:", rep_state_names[i], "and", rep_state_names[i + 1]),
      subtitle = "Posterior Median with 50% and 90% Prediction Intervals (Dashed line = Forecast Horizon Start)",
      x = "Week",
      y = "Weekly Count",
      color = "Stream",
      fill = "Stream"
    ) +
    theme_bw(base_size = 11) +
    theme(
      legend.position = "bottom",
      plot.title = element_text(face = "bold", size = 13),
      strip.text = element_text(face = "bold", size = 10),
      panel.grid.minor = element_blank()
    )
  
  print(p_pair)
}

dev.off()

cat("✔ PDF Successfully Saved: Representative_Geopolitical_Zones_Forecasts.pdf\n")






# Check if state_all_targets exists in memory; if not, read from saved CSV
if (!exists("state_all_targets")) {
  cat("Reading forecast data from CSV...\n")
  state_all_targets <- read.csv("maepims_state_level_52week_forecasts.csv")
}

cat("Generating Representative Zone Forecast Plots PDF...\n")

df_rep_states <- state_all_targets %>%
  filter(state %in% c("Benue", "Bayelsa", "Enugu", "Lagos", "Kano", "Sokoto")) %>%
  mutate(
    state = factor(state, levels = c("Benue", "Bayelsa", "Enugu", "Lagos", "Kano", "Borno")),
    target = factor(target, levels = c("Cases", "Hospitalizations", "Deaths"))
  )

rep_state_names <- levels(df_rep_states$state)

# Safe rendering wrapper using tryCatch/finally
tryCatch({
  pdf("Representative_Geopolitical_Zones_Forecasts.pdf", width = 12, height = 8.5)
  
  for (i in seq(1, length(rep_state_names), by = 2)) {
    p_pair <- ggplot(
      df_rep_states %>% filter(state %in% rep_state_names[i:(i + 1)]),
      aes(x = week, y = median, fill = target, color = target)
    ) +
      geom_vline(xintercept = T_obs + 0.5, linetype = "dashed", color = "grey40", linewidth = 0.7) +
      geom_ribbon(aes(ymin = q5, ymax = q95), alpha = 0.18, color = NA) +
      geom_ribbon(aes(ymin = q25, ymax = q75), alpha = 0.35, color = NA) +
      geom_line(linewidth = 0.9) +
      facet_grid(target ~ state, scales = "free_y") +
      scale_x_continuous(breaks = seq(0, T_total, by = 8)) +
      scale_y_continuous(labels = scales::comma) +
      scale_color_manual(values = c("Cases" = "#2B8CBE", "Hospitalizations" = "#E6550D", "Deaths" = "#7570B3")) +
      scale_fill_manual(values = c("Cases" = "#2B8CBE", "Hospitalizations" = "#E6550D", "Deaths" = "#7570B3")) +
      labs(
        title = paste("52-Week Multi-Stream Forecasts:", rep_state_names[i], "and", rep_state_names[i + 1]),
        subtitle = "Posterior Median with 50% and 90% Prediction Intervals (Dashed line = Forecast Horizon Start)",
        x = "Week",
        y = "Weekly Count",
        color = "Stream",
        fill = "Stream"
      ) +
      theme_bw(base_size = 11) +
      theme(
        legend.position = "bottom",
        plot.title = element_text(face = "bold", size = 13),
        strip.text = element_text(face = "bold", size = 10),
        panel.grid.minor = element_blank()
      )
    
    print(p_pair)
  }
}, finally = {
  if (dev.cur() > 1) dev.off() # Guarantees device closes even if an error occurs
})

cat("✔ PDF Successfully Saved: Representative_Geopolitical_Zones_Forecasts.pdf\n")
