"""
check_theory.py - numerical verification of the analytical results used in
the report (random parameter sets; autonomous model, delta_c = delta_2 = 0):
  1. closed-form R_0 (eq:flu_R0, eta_A = 1) == spectral radius of F V^{-1}
  2. DFE is an equilibrium of the ODE
  3. d_6 = det(V)(1 - R_0): det(V - F) = det(V)(1 - R_0)   (rank-one F)
  4. for R_0 > 1 the long-run force of infection of the simulated ODE equals
     the positive root of the endemic quadratic a2 L^2 + a1 L + a0 = 0
Run: python src/check_theory.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model import (R0_closed_form, R0_ngm, dfe, endemic_quadratic, ngm_matrices,  # noqa: E402
                   rhs)


def random_params(rng):
    u = lambda a, b: float(rng.uniform(a, b))  # noqa: E731
    p = dict(mu=u(1e-4, 1e-3), sigma=u(0.2, 1), theta=u(0.1, 0.6), gamma_A=u(0.1, 0.5),
             gamma_I=u(0.1, 0.4), gamma_H=u(0.05, 0.3), gamma_T=u(0.1, 0.5), gamma_Q=u(0.1, 0.4),
             alpha_A=u(0, 0.05), alpha=u(0, 0.1), alpha_H=u(0, 0.2), phi_A=u(0, 0.05),
             phi_I=u(0, 0.1), phi_H=u(0, 0.1), rho=u(0.001, 0.05), delta_I=u(0, 0.01),
             delta_H=u(0, 0.05), eta_I=u(0.5, 1.5), eta_H=u(0.05, 0.5), eta_T=u(0.1, 0.8),
             eta_Q=u(0.05, 0.5), eps_V=u(0, 0.9), omega=u(0, 0.01), xi=u(0.001, 0.02),
             kappa=u(0.005, 0.05), beta_0=u(0.1, 1.0), delta_c=0.0, delta_2=0.0, phi=0.0, phi_2=0.0)
    p["Lambda"] = p["mu"] * 1e6
    return p


def main(n=200, seed=7):
    rng = np.random.default_rng(seed)
    worst = dict(R0=0.0, dfe=0.0, d6=0.0)
    for _ in range(n):
        p = random_params(rng)
        worst["R0"] = max(worst["R0"], abs(R0_closed_form(p) - R0_ngm(p)) / R0_ngm(p))
        S0, V0 = dfe(p)
        f = np.array(rhs(0, [S0, V0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], p)[:9])
        worst["dfe"] = max(worst["dfe"], np.max(np.abs(f)) / p["Lambda"])
        F, V, _ = ngm_matrices(p)
        lhs = np.linalg.det(V - F)
        rhs_ = np.linalg.det(V) * (1 - R0_closed_form(p))
        worst["d6"] = max(worst["d6"], abs(lhs - rhs_) / abs(np.linalg.det(V)))
    print("max rel. error closed-form vs NGM R0   :", f"{worst['R0']:.2e}")
    print("max |f(DFE)| / Lambda                  :", f"{worst['dfe']:.2e}")
    print("max |det(V-F) - det(V)(1-R0)| / det(V) :", f"{worst['d6']:.2e}")
    ok = all(v < 1e-9 for v in worst.values())

    # endemic equilibrium check (a few supercritical parameter sets)
    errs = []
    tries = 0
    while len(errs) < 5 and tries < 200:
        tries += 1
        p = random_params(rng)
        if R0_closed_form(p) < 1.3:
            continue
        S0, V0 = dfe(p)
        y0 = [S0 * 0.99, V0, S0 * 0.01, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        sol = solve_ivp(rhs, (0, 40000), y0, args=(p,), method="LSODA", rtol=1e-10, atol=1e-8)
        S, V, E, A, I, H, T, Q, R = sol.y[:9, -1]
        N = S + V + E + A + I + H + T + Q + R
        lam_sim = p["beta_0"] / N * (A + p["eta_I"] * I + p["eta_H"] * H + p["eta_T"] * T + p["eta_Q"] * Q)
        q = endemic_quadratic(p)
        roots = np.roots([q["a2"], q["a1"], q["a0"]])
        pos = roots[(np.isreal(roots)) & (roots.real > 0)].real
        if len(pos) != 1:
            continue
        errs.append(abs(lam_sim - pos[0]) / pos[0])
    print("endemic: max rel. error simulated lambda* vs quadratic root:", f"{max(errs):.2e}",
          f"({len(errs)} sets)")
    ok = ok and max(errs) < 1e-4
    print("ALL CHECKS PASSED" if ok else "CHECK FAILED")
    return ok


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
